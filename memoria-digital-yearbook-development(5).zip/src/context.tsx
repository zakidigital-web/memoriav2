
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Alumni, Teacher, Yearbook, mockAlumni, mockTeachers, mockYearbooks } from './types';

interface AppContextType {
  alumni: Alumni[];
  teachers: Teacher[];
  yearbooks: Yearbook[];
  isAdmin: boolean;
  login: (username: string, password: string) => boolean;
  logout: () => void;
  addAlumni: (data: Alumni) => void;
  updateAlumni: (id: string, data: Alumni) => void;
  deleteAlumni: (id: string) => void;
  addTeacher: (data: Teacher) => void;
  updateTeacher: (id: string, data: Teacher) => void;
  deleteTeacher: (id: string) => void;
  addYearbook: (data: Yearbook) => void;
  updateYearbook: (id: string, data: Yearbook) => void;
  deleteYearbook: (id: string) => void;
  schoolInfo: any;
  updateSchoolInfo: (data: any) => void;
  theme: 'light' | 'dark';
  setTheme: (theme: 'light' | 'dark') => void;
  toggleTheme: () => void;
  yearbookSettings: any;
  updateYearbookSettings: (data: any) => void;
  primaryColor: string;
  setPrimaryColor: (color: string) => void;
  isAlumniVisible: boolean;
  setIsAlumniVisible: (visible: boolean) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [alumni, setAlumni] = useState<Alumni[]>(() => {
    const saved = localStorage.getItem('memoria_alumni');
    return saved ? JSON.parse(saved) : mockAlumni;
  });
  const [teachers, setTeachers] = useState<Teacher[]>(() => {
    const saved = localStorage.getItem('memoria_teachers');
    return saved ? JSON.parse(saved) : mockTeachers;
  });
  const [yearbooks, setYearbooks] = useState<Yearbook[]>(() => {
    const saved = localStorage.getItem('memoria_yearbooks');
    return saved ? JSON.parse(saved) : mockYearbooks;
  });
  const [schoolInfo, setSchoolInfo] = useState(() => {
    const saved = localStorage.getItem('memoria_school');
    return saved ? JSON.parse(saved) : {
      name: 'SMP Negeri 1 Jakarta',
      logo: 'https://upload.wikimedia.org/wikipedia/commons/9/9c/Logo_Tut_Wuri_Handayani.png',
      defaultTheme: 'light',
      history: 'Didirikan pada tahun 1950...',
      vision: 'Menjadi sekolah unggulan dalam IPTEK dan IMTAK.',
      mission: '1. Meningkatkan kualitas pembelajaran...',
      facilities: 'Lab Komputer, Perpustakaan Digital, GOR.'
    };
  });

  const [primaryColor, setPrimaryColor] = useState(() => {
    return localStorage.getItem('memoria_primary_color') || '#2563eb';
  });

  const [isAlumniVisible, setIsAlumniVisible] = useState(() => {
    const saved = localStorage.getItem('memoria_alumni_visible');
    return saved === null ? true : saved === 'true';
  });

  useEffect(() => {
    localStorage.setItem('memoria_primary_color', primaryColor);
    document.documentElement.style.setProperty('--primary-color', primaryColor);
  }, [primaryColor]);

  useEffect(() => {
    localStorage.setItem('memoria_alumni_visible', isAlumniVisible.toString());
  }, [isAlumniVisible]);

  const [yearbookSettings, setYearbookSettings] = useState(() => {
    const saved = localStorage.getItem('memoria_yearbook_settings');
    return saved ? JSON.parse(saved) : {
      sortBy: 'year-desc',
      gridColumns: 4,
      showStudentCount: true
    };
  });

  const [theme, setTheme] = useState<'light' | 'dark'>(() => {
    const savedUserTheme = localStorage.getItem('memoria_theme');
    if (savedUserTheme) return savedUserTheme as 'light' | 'dark';
    
    // Check school info for default theme
    const savedSchool = localStorage.getItem('memoria_school');
    if (savedSchool) {
      try {
        const parsed = JSON.parse(savedSchool);
        if (parsed.defaultTheme) return parsed.defaultTheme;
      } catch (e) {}
    }
    return 'light';
  });

  useEffect(() => {
    localStorage.setItem('memoria_theme', theme);
    const root = window.document.documentElement;
    if (theme === 'dark') {
      root.classList.add('dark');
      root.style.colorScheme = 'dark';
    } else {
      root.classList.remove('dark');
      root.style.colorScheme = 'light';
    }
  }, [theme]);

  useEffect(() => {
    localStorage.setItem('memoria_yearbook_settings', JSON.stringify(yearbookSettings));
  }, [yearbookSettings]);

  useEffect(() => {
    localStorage.setItem('memoria_teachers', JSON.stringify(teachers));
  }, [teachers]);

  useEffect(() => {
    localStorage.setItem('memoria_school', JSON.stringify(schoolInfo));
  }, [schoolInfo]);
  const [isAdmin, setIsAdmin] = useState(() => {
    return localStorage.getItem('memoria_isAdmin') === 'true';
  });

  useEffect(() => {
    localStorage.setItem('memoria_alumni', JSON.stringify(alumni));
  }, [alumni]);

  useEffect(() => {
    localStorage.setItem('memoria_yearbooks', JSON.stringify(yearbooks));
  }, [yearbooks]);

  const login = (username: string, password: string) => {
    if (username === 'admin' && password === 'admin123') {
      setIsAdmin(true);
      localStorage.setItem('memoria_isAdmin', 'true');
      return true;
    }
    return false;
  };

  const logout = () => {
    setIsAdmin(false);
    localStorage.removeItem('memoria_isAdmin');
  };

  const addAlumni = (data: Alumni) => setAlumni(prev => [...prev, data]);
  const updateAlumni = (id: string, data: Alumni) => 
    setAlumni(prev => prev.map(a => a.id === id ? data : a));
  const deleteAlumni = (id: string) => 
    setAlumni(prev => prev.filter(a => a.id !== id));
  
  const addYearbook = (data: Yearbook) => setYearbooks(prev => [...prev, data]);
  const updateYearbook = (id: string, data: Yearbook) => 
    setYearbooks(prev => prev.map(y => y.id === id ? data : y));
  
  const addTeacher = (data: Teacher) => setTeachers(prev => [...prev, data]);
  const updateTeacher = (id: string, data: Teacher) => 
    setTeachers(prev => prev.map(t => t.id === id ? data : t));
  const deleteTeacher = (id: string) => 
    setTeachers(prev => prev.filter(t => t.id !== id));
  
  const updateSchoolInfo = (data: any) => setSchoolInfo(data);
  const updateYearbookSettings = (data: any) => setYearbookSettings(data);
  const deleteYearbook = (id: string) => setYearbooks(prev => prev.filter(y => y.id !== id));
  const toggleTheme = () => setTheme(prev => prev === 'light' ? 'dark' : 'light');

  return (
    <AppContext.Provider value={{ 
      alumni, teachers, yearbooks, isAdmin, 
      login, logout, addAlumni, updateAlumni, deleteAlumni, 
      addTeacher, updateTeacher, deleteTeacher,
      addYearbook, updateYearbook, deleteYearbook, schoolInfo, updateSchoolInfo,
      theme, setTheme, toggleTheme, yearbookSettings, updateYearbookSettings,
      primaryColor, setPrimaryColor, isAlumniVisible, setIsAlumniVisible
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
};
