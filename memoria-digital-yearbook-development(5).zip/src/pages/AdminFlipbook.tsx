
import React, { useCallback, useState } from 'react';
import { useDropzone } from 'react-dropzone';
import { Upload, FileText, CheckCircle2, X, ArrowRight, Loader2, Music } from 'lucide-react';
import { useApp } from '../context';
import { useNavigate } from 'react-router-dom';
import * as pdfjsLib from 'pdfjs-dist';

// Sinkronkan versi Worker dengan API agar tidak terjadi mismatch
pdfjsLib.GlobalWorkerOptions.workerSrc = `https://unpkg.com/pdfjs-dist@${pdfjsLib.version}/build/pdf.worker.min.js`;

const AdminFlipbook: React.FC = () => {
  const { addYearbook } = useApp();
  const navigate = useNavigate();
  const [file, setFile] = useState<File | null>(null);
  const [isUploading, setIsUploading] = useState(false);
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    title: '',
    year: 2024,
    students: 120,
    classes: 3,
    musicUrl: '',
    musicFileName: ''
  });

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setFile(acceptedFiles[0]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({ 
    onDrop, 
    accept: { 'application/pdf': ['.pdf'], 'image/*': ['.jpg', '.jpeg', '.png'] },
    multiple: false 
  });

  const convertPdfToImages = async (pdfFile: File): Promise<string[]> => {
    let pdf;
    try {
      const arrayBuffer = await pdfFile.arrayBuffer();
      const data = new Uint8Array(arrayBuffer);
      
      const loadingTask = pdfjsLib.getDocument({
        data: data,
        useSystemFonts: true,
        disableFontFace: false
      });
      
      pdf = await loadingTask.promise;
      const images: string[] = [];
      
      // Batasi 10 halaman saja untuk stabilitas demo klien
      const pageCount = Math.min(pdf.numPages, 10);

      for (let i = 1; i <= pageCount; i++) {
        const page = await pdf.getPage(i);
        const viewport = page.getViewport({ scale: 1.0 });
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        
        if (!context) continue;

        canvas.height = viewport.height;
        canvas.width = viewport.width;

        const renderContext = {
          canvasContext: context,
          viewport: viewport,
          // @ts-ignore
          canvas: canvas
        };

        // @ts-ignore
        await page.render(renderContext).promise;
        
        // Kompresi lebih tinggi (0.4) untuk menghindari limit LocalStorage
        images.push(canvas.toDataURL('image/jpeg', 0.4));
        
        // Bebaskan memori segera
        canvas.width = 0;
        canvas.height = 0;
      }
      return images;
    } catch (err: any) {
      console.error('PDF Error Details:', err);
      throw new Error(`PDF Error: ${err.message || 'Unknown error'}`);
    } finally {
      if (pdf) {
        // @ts-ignore
        pdf.destroy?.();
      }
    }
  };

  const handleUpload = async () => {
    if (!file) return;
    setIsUploading(true);

    try {
      let pageImages: string[] = [];
      let coverImage = '';

      if (file.type === 'application/pdf') {
        pageImages = await convertPdfToImages(file);
        coverImage = pageImages[0];
      } else {
        // Handle images
        const imageUrl = URL.createObjectURL(file);
        coverImage = imageUrl;
        pageImages = [imageUrl]; // If single image, just one page
      }

      const newBook = {
        id: Math.random().toString(36).substr(2, 9),
        title: formData.title,
        year: formData.year,
        totalStudents: formData.students,
        totalClasses: formData.classes,
        backgroundMusic: formData.musicUrl,
        coverImage: coverImage,
        pages: pageImages
      };
      
      addYearbook(newBook);
      setStep(3);
    } catch (error: any) {
      console.error('Error processing file:', error);
      alert(`Gagal memproses: ${error.message || 'File mungkin terlalu besar atau tidak didukung'}`);
    } finally {
      setIsUploading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="mb-8">
        <h1 className="text-3xl font-bold text-slate-900">Upload Flipbook</h1>
        <p className="text-slate-500 mt-1">Konversi dokumen PDF atau gambar menjadi buku tahunan digital.</p>
      </div>

      {/* Progress Steps */}
      <div className="flex items-center gap-4 mb-10">
        {[1, 2, 3].map(s => (
          <React.Fragment key={s}>
            <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold transition-colors ${step >= s ? 'bg-blue-600 text-white' : 'bg-slate-200 text-slate-400'}`}>
              {s === 3 && step === 3 ? <CheckCircle2 size={20} /> : s}
            </div>
            {s < 3 && <div className={`flex-1 h-1 rounded-full ${step > s ? 'bg-blue-600' : 'bg-slate-200'}`} />}
          </React.Fragment>
        ))}
      </div>

      <div className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm">
        {step === 1 && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
             <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="flex flex-col gap-1.5">
                  <label className="text-sm font-bold text-slate-700">Judul Album</label>
                  <input 
                    type="text" 
                    placeholder="Contoh: Angkatan 2024"
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    value={formData.title}
                    onChange={e => setFormData({...formData, title: e.target.value})}
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-sm font-bold text-slate-700">Tahun Kelulusan</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    value={formData.year}
                    onChange={e => setFormData({...formData, year: parseInt(e.target.value)})}
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-sm font-bold text-slate-700">Total Siswa</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    value={formData.students}
                    onChange={e => setFormData({...formData, students: parseInt(e.target.value)})}
                  />
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-sm font-bold text-slate-700">Total Kelas</label>
                  <input 
                    type="number" 
                    className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    value={formData.classes}
                    onChange={e => setFormData({...formData, classes: parseInt(e.target.value)})}
                  />
                </div>
                <div className="flex flex-col gap-1.5 md:col-span-2">
                  <label className="text-sm font-bold text-slate-700 flex items-center gap-2">
                    <Music size={16} className="text-blue-600" /> Musik Latar (MP3/M4A)
                  </label>
                  <div className="flex items-center gap-3">
                    <label className="flex-1 flex items-center justify-between px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl cursor-pointer hover:bg-slate-100 transition-colors">
                      <span className="text-sm text-slate-500 truncate">
                        {formData.musicFileName || 'Klik untuk pilih file audio atau masukkan link...'}
                      </span>
                      <Upload size={18} className="text-slate-400" />
                      <input 
                        type="file" 
                        accept="audio/mp3,audio/mpeg,audio/x-m4a,audio/mp4" 
                        className="hidden" 
                        onChange={(e) => {
                          const file = e.target.files?.[0];
                          if (file) {
                            if (file.size > 2 * 1024 * 1024) {
                              alert('Ukuran file terlalu besar! Maksimal 2MB untuk menjaga performa.');
                              return;
                            }
                            setFormData({...formData, musicFileName: file.name, musicUrl: URL.createObjectURL(file)});
                          }
                        }}
                      />
                    </label>
                    <div className="w-px h-8 bg-slate-200" />
                    <input 
                      type="text" 
                      placeholder="Atau tempel link MP3 di sini..."
                      className="flex-1 px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none text-sm"
                      value={formData.musicUrl.startsWith('blob:') ? '' : formData.musicUrl}
                      onChange={e => setFormData({...formData, musicUrl: e.target.value, musicFileName: ''})}
                    />
                  </div>
                  <p className="text-[10px] text-slate-400 mt-1 italic">
                    *Maksimal 2MB. Format .mp3 atau .m4a sangat disarankan.
                  </p>
                </div>
             </div>
             <button 
                disabled={!formData.title}
                onClick={() => setStep(2)}
                className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
             >
                Lanjutkan <ArrowRight size={20} />
             </button>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-6 animate-in slide-in-from-right-4 duration-300">
             {!file ? (
               <div 
                {...getRootProps()} 
                className={`border-4 border-dashed rounded-3xl p-12 flex flex-col items-center justify-center transition-colors cursor-pointer ${isDragActive ? 'border-blue-400 bg-blue-50' : 'border-slate-100 bg-slate-50 hover:border-blue-200'}`}
               >
                  <input {...getInputProps()} />
                  <div className="w-20 h-20 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center mb-6">
                     <Upload size={32} />
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">Pilih File Dokumen</h3>
                  <p className="text-slate-500 text-center max-w-sm">
                    Tarik dan lepaskan file PDF atau gambar (JPG/PNG) di sini, atau klik untuk memilih file dari komputer Anda.
                  </p>
                  <p className="text-xs text-slate-400 mt-6 uppercase font-bold tracking-widest">Maksimal 50MB</p>
               </div>
             ) : (
               <div className="bg-slate-50 p-6 rounded-2xl flex items-center justify-between border border-blue-100">
                  <div className="flex items-center gap-4">
                     <div className="w-12 h-12 bg-blue-600 text-white rounded-xl flex items-center justify-center">
                        <FileText size={24} />
                     </div>
                     <div>
                        <p className="font-bold text-slate-900">{file.name}</p>
                        <p className="text-xs text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB • Siap diunggah</p>
                     </div>
                  </div>
                  <button onClick={() => setFile(null)} className="p-2 text-slate-400 hover:text-red-500"><X size={20} /></button>
               </div>
             )}

             <div className="flex gap-4">
                <button 
                  onClick={() => setStep(1)}
                  className="px-8 py-4 bg-slate-100 text-slate-600 rounded-2xl font-bold hover:bg-slate-200"
                >
                  Kembali
                </button>
                <button 
                  disabled={!file || isUploading}
                  onClick={handleUpload}
                  className="flex-1 py-4 bg-blue-600 text-white rounded-2xl font-bold hover:bg-blue-700 disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isUploading ? <><Loader2 size={20} className="animate-spin" /> Mengonversi...</> : 'Mulai Proses Unggah'}
                </button>
             </div>
          </div>
        )}

        {step === 3 && (
          <div className="text-center py-8 space-y-6 animate-in zoom-in duration-300">
             <div className="w-24 h-24 bg-emerald-100 text-emerald-600 rounded-full flex items-center justify-center mx-auto mb-6">
                <CheckCircle2 size={48} />
             </div>
             <div>
                <h2 className="text-2xl font-bold text-slate-900">Album Berhasil Dibuat!</h2>
                <p className="text-slate-500 mt-2">Buku tahunan digital Anda sekarang sudah tersedia untuk dilihat oleh publik.</p>
             </div>
             <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <button 
                  onClick={() => navigate('/koleksi')}
                  className="px-8 py-3 bg-blue-600 text-white rounded-xl font-bold hover:bg-blue-700"
                >
                  Lihat Hasil Flipbook
                </button>
                <button 
                  onClick={() => { setStep(1); setFile(null); setFormData({ title: '', year: 2024, students: 120, classes: 3, musicUrl: '', musicFileName: '' }); }}
                  className="px-8 py-3 bg-slate-100 text-slate-600 rounded-xl font-bold hover:bg-slate-200"
                >
                  Upload Album Lain
                </button>
             </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default AdminFlipbook;
