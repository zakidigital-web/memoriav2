
import React, { useState } from 'react';
import { useApp } from '../context';
import { 
  Shield, 
  Lock, 
  User, 
  Palette, 
  Globe, 
  Save, 
  Image as ImageIcon,
  BookOpen,
  LayoutGrid,
  Moon,
  Sun,
  GraduationCap
} from 'lucide-react';

const AdminSettings: React.FC = () => {
  const { schoolInfo, updateSchoolInfo, setTheme, yearbookSettings, updateYearbookSettings, primaryColor, setPrimaryColor, isAlumniVisible, setIsAlumniVisible } = useApp();
  const [activeTab, setActiveTab] = useState('Akun');
  const [status, setStatus] = useState('');
  
  const [localSchool, setLocalSchool] = useState(schoolInfo);
  const [localYB, setLocalYB] = useState(yearbookSettings);

  const tabs = [
    { name: 'Akun', icon: Shield },
    { name: 'Sekolah', icon: ImageIcon },
    { name: 'Flipbook', icon: BookOpen },
    { name: 'Tampilan', icon: Palette },
    { name: 'Sistem', icon: Globe },
  ];

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    updateSchoolInfo(localSchool);
    updateYearbookSettings(localYB);
    setStatus('Pengaturan diperbarui!');
    setTimeout(() => setStatus(''), 3000);
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold text-slate-900">Pengaturan Aplikasi</h1>
          <p className="text-slate-500 mt-1">Konfigurasi keamanan, logo, dan preferensi sistem.</p>
        </div>
        {status && <div className="bg-emerald-100 text-emerald-600 px-4 py-2 rounded-xl text-sm font-bold animate-in fade-in slide-in-from-top-2">{status}</div>}
      </div>

      <div className="flex flex-col md:flex-row gap-8">
        {/* Sidebar Tabs */}
        <div className="w-full md:w-56 flex flex-col gap-2">
          {tabs.map(tab => (
            <button
              key={tab.name}
              onClick={() => setActiveTab(tab.name)}
              className={`flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-bold transition-all ${activeTab === tab.name ? 'bg-blue-600 text-white shadow-lg shadow-blue-600/20' : 'text-slate-500 hover:bg-white hover:text-slate-900'}`}
            >
              <tab.icon size={18} />
              {tab.name}
            </button>
          ))}
        </div>

        {/* Content Area */}
        <div className="flex-1">
          <form onSubmit={handleSave} className="bg-white p-8 rounded-3xl border border-slate-100 shadow-sm space-y-8">
            {activeTab === 'Akun' && (
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="flex flex-col gap-1.5">
                  <label className="text-sm font-bold text-slate-700">Username Admin</label>
                  <div className="relative">
                    <User className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="text" 
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                      defaultValue="admin"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-1.5">
                  <label className="text-sm font-bold text-slate-700">Kata Sandi Baru</label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                    <input 
                      type="password" 
                      placeholder="••••••••"
                      className="w-full pl-10 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                    />
                  </div>
                </div>
              </div>
            )}

            {activeTab === 'Sekolah' && (
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="flex flex-col gap-4">
                  <label className="text-sm font-bold text-slate-700">Logo Sekolah</label>
                  <div className="flex items-center gap-6 p-6 bg-slate-50 rounded-2xl border border-slate-200 border-dashed">
                    <div className="w-20 h-20 bg-white rounded-2xl flex items-center justify-center p-2 shadow-sm border border-slate-100">
                       <img src={localSchool.logo} alt="School Logo" className="max-w-full max-h-full object-contain" />
                    </div>
                    <div className="flex-1 space-y-2">
                       <p className="text-xs text-slate-500">Masukkan URL logo sekolah (Format PNG/JPG disarankan)</p>
                       <input 
                        type="text" 
                        className="w-full px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm outline-none focus:ring-2 focus:ring-blue-500/20"
                        value={localSchool.logo}
                        onChange={e => setLocalSchool({...localSchool, logo: e.target.value})}
                       />
                    </div>
                  </div>
                </div>
                <div className="flex flex-col gap-1.5">
                    <label className="text-sm font-bold text-slate-700">Nama Sekolah</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                      value={localSchool.name}
                      onChange={e => setLocalSchool({...localSchool, name: e.target.value})}
                    />
                 </div>
              </div>
            )}

            {activeTab === 'Flipbook' && (
              <div className="space-y-6 animate-in fade-in duration-300">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="flex flex-col gap-1.5">
                    <label className="text-sm font-bold text-slate-700">Urutkan Berdasarkan</label>
                    <select 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                      value={localYB.sortBy}
                      onChange={e => setLocalYB({...localYB, sortBy: e.target.value})}
                    >
                      <option value="year-desc">Tahun Terbaru</option>
                      <option value="year-asc">Tahun Terlama</option>
                      <option value="title-asc">Judul (A-Z)</option>
                    </select>
                  </div>
                  <div className="flex flex-col gap-1.5">
                    <label className="text-sm font-bold text-slate-700">Kolom Grid (Desktop)</label>
                    <div className="flex items-center gap-4 bg-slate-50 p-2 rounded-xl border border-slate-200">
                      {[3, 4, 6].map(num => (
                        <button
                          key={num}
                          type="button"
                          onClick={() => setLocalYB({...localYB, gridColumns: num})}
                          className={`flex-1 py-2 rounded-lg text-sm font-bold transition-all ${localYB.gridColumns === num ? 'bg-white text-blue-600 shadow-sm' : 'text-slate-400'}`}
                        >
                          {num} Kolom
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
                 <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                    <div className="flex items-center gap-3">
                       <LayoutGrid className="text-blue-500" size={20} />
                       <div>
                          <p className="text-sm font-bold text-slate-900">Tampilkan Jumlah Siswa</p>
                          <p className="text-xs text-slate-500">Tampilkan info jumlah siswa di kartu buku</p>
                       </div>
                    </div>
                    <button 
                      type="button"
                      onClick={() => setLocalYB({...localYB, showStudentCount: !localYB.showStudentCount})}
                      className={`w-12 h-6 rounded-full transition-colors relative ${localYB.showStudentCount ? 'bg-blue-600' : 'bg-slate-300'}`}
                    >
                       <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${localYB.showStudentCount ? 'right-1' : 'left-1'}`} />
                    </button>
                 </div>

                 <div className="flex items-center justify-between p-4 bg-slate-50 rounded-2xl">
                    <div className="flex items-center gap-3">
                       <div className="w-10 h-10 bg-rose-50 text-rose-600 rounded-xl flex items-center justify-center">
                          <GraduationCap size={20} />
                       </div>
                       <div>
                          <p className="text-sm font-bold text-slate-900">Menu Angkatan / Alumni</p>
                          <p className="text-xs text-slate-500">Aktifkan atau nonaktifkan fitur daftar angkatan publik</p>
                       </div>
                    </div>
                    <button 
                      type="button"
                      onClick={() => setIsAlumniVisible(!isAlumniVisible)}
                      className={`w-12 h-6 rounded-full transition-colors relative ${isAlumniVisible ? 'bg-blue-600' : 'bg-slate-300'}`}
                    >
                       <div className={`absolute top-1 w-4 h-4 bg-white rounded-full transition-all ${isAlumniVisible ? 'right-1' : 'left-1'}`} />
                    </button>
                 </div>
              </div>
            )}

            {activeTab === 'Tampilan' && (
              <div className="space-y-6 animate-in fade-in duration-300">
                 <div className="flex flex-col gap-4">
                    <label className="text-sm font-bold text-slate-700">Warna Identitas Aplikasi</label>
                    <p className="text-xs text-slate-500 mb-2">Pilih warna utama yang akan digunakan di seluruh aplikasi.</p>
                    <div className="grid grid-cols-5 gap-4">
                       {['#2563eb', '#10b981', '#f59e0b', '#ef4444', '#8b5cf6'].map(color => (
                         <button
                           key={color}
                           type="button"
                           onClick={() => setPrimaryColor(color)}
                           className={`w-full aspect-square rounded-2xl border-4 transition-all ${primaryColor === color ? 'border-slate-900 shadow-lg scale-110' : 'border-transparent'}`}
                           style={{ backgroundColor: color }}
                         />
                       ))}
                       <div className="col-span-5 flex items-center gap-4 mt-2">
                          <input 
                            type="color" 
                            value={primaryColor} 
                            onChange={(e) => setPrimaryColor(e.target.value)}
                            className="w-12 h-12 rounded-xl cursor-pointer bg-white border border-slate-200 p-1"
                          />
                          <span className="text-sm font-mono text-slate-600 uppercase">{primaryColor}</span>
                       </div>
                    </div>
                 </div>
                 <div className="flex flex-col gap-4 pt-6 border-t border-slate-100">
                    <label className="text-sm font-bold text-slate-700">Tema Default Aplikasi</label>
                    <p className="text-xs text-slate-500">Tentukan tampilan awal untuk pengunjung baru.</p>
                    <div className="grid grid-cols-2 gap-4">
                       <button
                        type="button"
                        onClick={() => {
                           setTheme('light');
                           setLocalSchool({...localSchool, defaultTheme: 'light'});
                        }}
                        className={`flex flex-col items-center gap-3 p-4 rounded-2xl border-2 transition-all ${localSchool.defaultTheme === 'light' ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-slate-100 bg-slate-50 text-slate-400'}`}
                       >
                          <Sun size={24} />
                          <span className="text-xs font-bold">Default: Terang</span>
                       </button>
                       <button
                        type="button"
                        onClick={() => {
                           setTheme('dark');
                           setLocalSchool({...localSchool, defaultTheme: 'dark'});
                        }}
                        className={`flex flex-col items-center gap-3 p-4 rounded-2xl border-2 transition-all ${localSchool.defaultTheme === 'dark' ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-slate-100 bg-slate-50 text-slate-400'}`}
                       >
                          <Moon size={24} />
                          <span className="text-xs font-bold">Default: Gelap</span>
                       </button>
                    </div>
                 </div>
              </div>
            )}

            {activeTab === 'Sistem' && (
              <div className="space-y-6 animate-in fade-in duration-300">
                 <div className="flex flex-col gap-1.5">
                    <label className="text-sm font-bold text-slate-700">Nama Aplikasi</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                      defaultValue="Memoria Digital Yearbook"
                    />
                 </div>
                 <div className="flex flex-col gap-1.5">
                    <label className="text-sm font-bold text-slate-700">Footer Text</label>
                    <input 
                      type="text" 
                      className="w-full px-4 py-3 bg-slate-50 border border-slate-200 rounded-xl outline-none"
                      defaultValue={`Copyright © 2024 ${schoolInfo.name}`}
                    />
                 </div>
              </div>
            )}

            <button 
              type="submit"
              className="w-full py-4 bg-blue-600 text-white rounded-2xl font-bold flex items-center justify-center gap-2 shadow-lg shadow-blue-600/20"
            >
              <Save size={20} /> Simpan Perubahan
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AdminSettings;
