
import React from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import { 
  LayoutDashboard, 
  School, 
  Users, 
  Book, 
  Settings, 
  LogOut,
  UserCog
} from 'lucide-react';
import { useApp } from '../context';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

const AdminLayout: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { logout, schoolInfo } = useApp();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/');
  };

  const menuItems = [
    { section: 'MAIN MENU', items: [
      { label: 'Dashboard', icon: LayoutDashboard, path: '/admin' },
      { label: 'Manajemen Flipbook', icon: Book, path: '/admin/manage-books' },
      { label: 'Data Sekolah', icon: School, path: '/admin/sekolah' },
      { label: 'Direktori Guru', icon: Users, path: '/admin/guru' },
      { label: 'Manajemen Siswa', icon: UserCog, path: '/admin/alumni' },
    ]},
    { section: 'SYSTEM', items: [
      { label: 'Pengaturan', icon: Settings, path: '/admin/settings' },
    ]}
  ];

  return (
    <div className="flex min-h-screen bg-slate-50 dark:bg-slate-950 transition-colors">
      {/* Sidebar */}
      <aside className="w-64 bg-white dark:bg-slate-900 border-r border-slate-200 dark:border-slate-800 flex flex-col fixed inset-y-0 left-0 z-50">
        <div className="p-6 flex items-center gap-3">
          <div className="w-10 h-10 bg-white dark:bg-slate-800 rounded-xl flex items-center justify-center p-1.5 shadow-sm border border-slate-100 dark:border-slate-700">
             {schoolInfo.logo ? (
                <img src={schoolInfo.logo} alt="Logo" className="max-w-full max-h-full object-contain" />
             ) : (
                <div className="text-blue-600 font-black text-xl">M</div>
             )}
          </div>
          <span className="text-xl font-bold text-slate-900 dark:text-white truncate">{schoolInfo.name.split(' ')[0]}</span>
        </div>

        <nav className="flex-1 px-4 py-4 flex flex-col gap-8">
          {menuItems.map((group) => (
            <div key={group.section} className="flex flex-col gap-2">
              <span className="px-4 text-[10px] font-bold text-slate-400 tracking-widest uppercase">
                {group.section}
              </span>
              {group.items.map((item) => (
                <NavLink
                  key={item.path}
                  to={item.path}
                  className={({ isActive }) => cn(
                    "flex items-center gap-3 px-4 py-3 rounded-xl text-sm font-medium transition-all",
                    isActive 
                      ? "bg-blue-50 text-blue-600" 
                      : "text-slate-500 hover:bg-slate-50 hover:text-slate-900"
                  )}
                >
                  <item.icon size={18} />
                  {item.label}
                </NavLink>
              ))}
            </div>
          ))}
        </nav>

        {/* Admin Profile */}
        <div className="p-4 border-t border-slate-100">
          <div className="bg-slate-50 p-3 rounded-2xl flex items-center gap-3">
            <img 
              src="https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&q=80&w=100" 
              alt="Admin" 
              className="w-10 h-10 rounded-full object-cover border-2 border-white"
            />
            <div className="flex-1 overflow-hidden">
              <p className="text-xs font-bold text-slate-900 truncate">Administrator</p>
              <p className="text-[10px] text-slate-400 truncate">Super Admin</p>
            </div>
          </div>
        </div>
      </aside>

      {/* Main Content Area */}
      <div className="flex-1 pl-64 flex flex-col">
        {/* Top bar */}
        <header className="h-16 bg-white dark:bg-slate-900 border-b border-slate-200 dark:border-slate-800 px-8 flex items-center justify-between sticky top-0 z-40">
          <span className="text-sm font-medium text-slate-600 dark:text-slate-400">Overview</span>
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 px-4 py-2 border border-red-100 text-red-500 rounded-lg text-sm font-medium hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors"
          >
            <LogOut size={16} /> Keluar
          </button>
        </header>

        <main className="flex-1 p-8">
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
